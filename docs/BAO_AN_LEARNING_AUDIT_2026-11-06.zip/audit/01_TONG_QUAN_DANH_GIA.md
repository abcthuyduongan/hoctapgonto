# Tổng quan kiểm toán Bảo An Learning 4.0.1

**Ngày kiểm toán: 06/11/2026, Asia/Saigon. Điểm tạm tính: 57/100. Chưa đủ điều kiện phát hành chính thức hoặc xác nhận C12 PASS toàn diện.**

Điểm là đánh giá kỹ thuật có giới hạn trên bằng chứng đợt này, không phải chứng nhận hay tỷ lệ hoàn thành dự án. Mã đã có tiến bộ đáng kể so với 4.0.0; các lỗi mới cho thấy những cổng nghiệm thu trước chưa bao phủ đủ điều kiện lỗi và thao tác thật.

## 1. Đối tượng và cách kiểm tra

| Thuộc tính | Giá trị |
| --- | --- |
| Dự án | Bảo An Learning, không phải ứng dụng TKB/điểm danh |
| Phiên bản mã đang kiểm tra | `4.0.1` |
| HEAD | `f7c93337669379d768419ae1ab43cbde69f2aabe`, nhiều thay đổi chưa commit |
| Runtime source ID | `59d67c93a8c3dd8839db1091c8760329f8d11c63984761ee5fe8342833bdff77` |
| Nền tảng | React 19, TypeScript, Vite, Node/SQLite; Netlify Functions/PostgreSQL/Supabase Storage |
| Quyền thực tế | `admin`, `student`, `parent` |
| Thực hiện | Inventory module/cấu hình/test, rà luồng và dữ liệu, build và full test, tái hiện độc lập, ảnh/axe, Performance API/CDP và benchmark dữ liệu |
| Giới hạn | Browser giả lập, DB thử; không có phép đo Supabase/thiết bị vật lý/người dùng thật của 4.0.1 |

Các mục TKB, GVCN/GVBM, sơ đồ ghế và điểm danh của prompt được ghi **KHÔNG ÁP DỤNG**. Các hành trình tương ứng được đánh giá theo nhập/giao học liệu, chơi học, phụ huynh và quản trị dữ liệu của sản phẩm thật. Không giả định có những phân hệ không tồn tại.

Không chỉnh sửa mã ứng dụng trong đợt này. Các thay đổi chưa commit của chủ dự án được giữ nguyên; chỉ tạo báo cáo và bằng chứng. Thư mục log tạm là `test-results/audit-2026-11-06/`; bản bàn giao có các chứng cứ cần thiết trong `docs/audit/evidence/`.

## 2. Chấm điểm theo yêu cầu

| Nhóm | Điểm | Bằng chứng/điểm mạnh | Hạn chế làm mất điểm | Mức tin cậy |
| --- | ---: | --- | --- | --- |
| Kiến trúc và chất lượng mã | **11/15** | Role/game lazy load; API/server scoring, phân trang, timeout; typecheck/build đạt | Hai store lớn, chính sách lặp, hợp đồng presentation chưa nối hết, migration gián đoạn | Cao với mã và luồng đã rà; chưa chứng nhận mọi nhánh |
| UI và đồ họa | **10/15** | Bản đồ nhẹ, tranh rõ phong cách, ảnh ba khổ và game có bối cảnh | Tương phản/ARIA/name lỗi, nhiều control và danh sách dài, chưa thử zoom thật/người dùng thật | Trung bình |
| UX và liền mạch | **10/20** | Nhiều luồng cơ bản/ACK/retry được kiểm thử, full browser tốt hơn | Mất bài khi timeout/autosave, chấm nhầm stale UI, ôn sai không mở, preview mất khi focus | Cao cho lỗi đã tái hiện; trung bình cho toàn bộ trải nghiệm |
| Hiệu năng và truy xuất | **16/30** | 54 mẫu browser; 23 lớp/1.000 HS benchmark; admin phân trang gọn | Mobile cold 4,0–4,7 s ở màn chính, game 3,5–3,9 s; CLS cao, CSS lớn; cloud/INP field chưa kiểm chứng | Trung bình, chỉ lab/SQLite |
| Bảo mật, ổn định, mở rộng | **7/15** | Session/CSRF/workspace, DTO, quyền parent mới có cải thiện, test hai backend | Restore có thể thay dữ liệu dù thất bại; backup không snapshot; PIN đổi qua đường không chịu lockout | Cao trong fixture; cấu hình production chưa kiểm chứng |
| Bảo trì và triển khai | **3/5** | Build identity, scripts, gói cục bộ, test phong phú | npm test còn 1 lỗi, chứng cứ thiếu, website chưa là 4.0.1, quy trình cloud backup chưa đầy đủ | Cao với artifact/endpoint đã đọc |
| **Tổng** | **57/100** | Nền tảng đáng giữ và cải tiến | Còn lỗi chặn nghiệm thu | Không dùng thay biên bản người dùng |

Không cho điểm tối đa ở các phần chưa thể kiểm chứng. Không cộng điểm bù cho lỗi P0 chỉ vì nhiều màn hoặc nhiều test PASS. Điểm có thể thay đổi khi lỗi được đóng và có số đo/bằng chứng mới.

## 3. Kết quả kiểm thử độc lập

| Nhóm | Kết quả mới |
| --- | --- |
| TypeScript | PASS |
| Build production | PASS |
| Assets | PASS theo ngưỡng hiện tại 8 MiB; 113 tệp, 5,08 MiB |
| Node release | 12/12 đạt |
| Node online | 263/263 đạt |
| Node cloud | **46 đạt, 1 lỗi** |
| Map | 26/26 đạt, chạy riêng sau khi npm test dừng |
| Curriculum kỹ thuật | 1/1 đạt, chạy riêng; không xác nhận đủ số lượng/duyệt chuyên môn |
| Pilot simulation | 1/1 đạt, chạy riêng; không phải học sinh thật |
| Full Playwright Chrome + Edge | **180 đạt, 2 bỏ qua, 0 lỗi, 0 chưa chạy**, 13,2 phút |
| Browser performance lab | 54 mẫu = 9 kịch bản × 2 profile × 3 lần, harness không có exception/pageerror |

`npm test` **exit 1** vì `tests/staging-rollback-rehearsal.test.mjs:103` vẫn đòi version `4.0.0`, thực tế `4.0.1`. Đây là kỳ vọng kiểm thử cũ, không tự chứng minh rollback dữ liệu hỏng; vẫn phải sửa để cổng chuẩn đạt. Các nhóm phía sau được chạy riêng để không bỏ sót.

Hai ca Playwright bỏ qua là cùng bài dùng tệp Excel riêng của tác giả trên hai browser, thiếu tệp cục bộ. Không tính SKIP thành PASS. Lần đầu build/test bị sandbox chặn ghi artifact/localhost; đã chạy lại với quyền phù hợp. Lỗi môi trường không được cộng vào lỗi sản phẩm.

Các chương trình kiểm toán bổ sung đã tái hiện lỗi mà bộ chuẩn chưa bao phủ: 7 ca bảo mật/dữ liệu, 5 ca lịch sử xáo/adapter, các ca UI về timeout/autosave/stale presentation/ôn sai/preview và a11y scope. **Assert PASS trong các chương trình tái hiện nghĩa là lỗi có thật**, không phải sản phẩm đạt nghiệm thu.

## 4. Mười vấn đề ưu tiên nhất

| # | Vấn đề | Mức | Tác động / hướng xử lý |
| --- | --- | --- | --- |
| 1 | Restore SQL commit trước media; preview/snapshot chưa đầy đủ | P0/P1 | Có thể thay dữ liệu dù restore thất bại; thiết kế staging/rollback và snapshot nhất quán — A01–A03 |
| 2 | Hết giờ thi gửi answers cũ/rỗng | P1 | Xóa bài đã lưu, điểm 0; chốt đáp án mới nhất trên server — U01 |
| 3 | Autosave cũ đến muộn ghi đè đáp án mới | P1 | UI/DB không khớp; revision/serialization và trạng thái lưu rõ — U02 |
| 4 | Client thiếu presentationId, anti-repeat không bền | P1 | Có thể chọn đúng vẫn sai; hoàn thiện contract và lịch sử bền — U03 và evidence shuffle-history |
| 5 | Đổi PIN qua oldPin bỏ qua lockout | P1 | Không giới hạn đầy đủ đường thử PIN; verifier/chính sách chung — A04 |
| 6 | Migration SQLite nuốt lỗi/không phục hồi sau ngắt | P1 | Schema cũ/dở vẫn được phục vụ; transaction, migration history, fail-fast — A05 |
| 7 | Ôn sai chỉ đóng modal, gói review sai schema | P1 | Không thực hiện được tác vụ học đã hứa; nối session ôn hợp lệ — U04 |
| 8 | Focus/refresh xóa preview nhập học liệu | P1 theo ảnh hưởng công việc | Giáo viên mất bản nháp; tách draft với server refresh — U05 |
| 9 | Cold/game tải chậm và UI có vấn đề truy cập | P1 hiệu năng/P2 UI | CSS/nền lớn, CLS cao, contrast/ARIA; tách tải, shell ổn định, sửa semantics — P01–P02, U06 |
| 10 | Công cụ và bằng chứng nghiệm thu báo quá phạm vi | P1 | Runner bỏ HTTP lỗi, nhóm 28 bị coi toàn bộ, thiếu evidence; sửa công cụ/CI và đối chiếu deploy — P03 |

Mỗi lỗi có vị trí, hiện trạng, tái hiện, nguyên nhân, tác động, cách sửa, lợi ích, rủi ro và nghiệm thu tại các báo cáo chuyên đề. Thứ tự sửa đặt mất dữ liệu/chấm sai trước để bảo toàn sản phẩm; phần hiệu năng được đo riêng đầy đủ, không đánh giá theo cảm giác.

## 5. Hiệu năng: kết luận có số đo

Profile điện thoại giả lập: CPU ×4, 390×844, CDP 1,6 Mib/s down, 150 ms latency cấu hình, không mất gói. Ba mẫu:

- Màn quản trị có phiên, cold cache: **4046 / 3986 / 4045 ms** tới mốc dùng được.
- Màn học sinh có phiên, cold cache: **4669 / 4712 / 4479 ms**; LCP quan sát **4684 / 4716 / 4500 ms**.
- Vào game: **3851 / 3582 / 3498 ms** tới lựa chọn có thể bấm.
- Lưu đáp án đúng→ACK: **418 / 434 / 455 ms** trong chuỗi thử bình thường.
- CSS chung game 268.623 B; request khoảng 2,7 s trên profile này. Khoảng 13–14% ký tự CSS được dùng trong chuỗi bản đồ→quiz→thoát đã đo; không được xóa phần còn lại mà chưa kiểm tra game khác.

SQLite data-access 23 lớp/1.000 học sinh/32.000 awards: trang học sinh 7 query, 0,901–1,906 ms; trang tuần 8 query, 0,485–0,835 ms. **Không phải thời gian Supabase hoặc tải đồng thời.** Chưa có bằng chứng cần viết lại backend; ưu tiên đường tải tài nguyên và lỗi hợp đồng, rồi đo cloud thật.

## 6. Đối chiếu báo cáo mới nhất và phát hành

Đã đọc `05_BAO_CAO_HOAN_THANH_NGHIEM_THU_4_0_1.md` và JSON nghiệm thu mới. Các thay đổi thực sự tốt: quyền parent/DTO, thêm bảng backup, export fail-fast, nạp nhiều migration, bộ chọn/luồng browser đã sửa, mô phỏng và duyệt kỹ thuật được ghi rõ hơn.

Các điểm chưa thể xác nhận như báo cáo:

- Browser report cũ trong `4.0.1-nghiem-thu` có 28 ca/10 tệp; đợt này mới chạy đầy đủ 182 ca. Fullsuite đạt không bao phủ tự động các ca race/timeout/stale state mới tìm thấy.
- Ma trận có 53 PASS nhưng **38 dòng PASS** trỏ ít nhất một tệp evidence không tồn tại tại đường được ghi. Có thể do log chưa lưu/đổi tên; cần sửa đường dẫn và gắn actual/build, không suy đoán ý định người ghi.
- Runner staging đã được tạo nhưng chưa đo được luồng học thật: inject 21 response 401/404 vẫn báo 0 lỗi. `PASS_SIMULATION` không đóng tiêu chí tải thật.
- Bộ học kỳ 2 vẫn có 85 câu/3 môn trong 8 tuần, chưa đủ tiêu chí 8×4×12 = 384 nếu giữ phạm vi; metadata đã thừa nhận cần giáo viên duyệt/bổ sung. Chủ dự án cung cấp nội dung, không giao AI tự ký duyệt.
- Gói `release.json` 4.0.1 vẫn `pilot:true`, `releaseReady:false`, `humanPilotStatus:UNVERIFIED`.
- [build-info website](https://gontogontet.netlify.app/build-info.json) và [API status](https://gontogontet.netlify.app/api/online/status) đọc ngày 06/11 vẫn trả **3.9.0-rc.1**, không phải 4.0.1. Chỉ áp dụng kết luận cho URL đã biết; không giả định các deploy khác.

## 7. Trả lời trực tiếp sáu câu hỏi của prompt

1. **Kiến trúc hợp lý chưa?** Hợp lý ở nền tảng phân vai, REST, server scoring, hai backend và lazy load. Cần giảm chính sách lặp và hoàn thiện transaction/contract; không cần viết lại toàn bộ.
2. **UI thống nhất, hiện đại và phù hợp điện thoại chưa?** Có phong cách tranh/bản đồ và bộ màu rõ, responsive cơ bản. Chưa đạt toàn diện vì tương phản, ARIA, mật độ nút/danh sách và zoom/thiết bị thật chưa kiểm chứng.
3. **Thao tác liền mạch chưa?** Luồng bình thường khá đầy đủ và browser suite đã cải thiện, nhưng timeout/autosave/ôn sai/preview/stale câu làm đứt gãy các tác vụ quan trọng.
4. **Nguyên nhân chậm chính là gì?** Trong lab: CSS game/nền tranh lớn, chuỗi chunk/ảnh phải tải, shell auth dư khi khôi phục phiên và layout shift. Độ trễ cloud/query thật chưa đo nên không kết luận Supabase chậm.
5. **Cải thiện đáng kể mà không viết lại được không?** Có hướng rõ: tách CSS/tài nguyên theo nhu cầu, ổn định shell, giữ phân trang và sửa chính sách/contract dùng chung. Mức tăng tốc phải đo trước/sau mới công bố.
6. **Mười cải tiến nên ưu tiên?** Chính là mười dòng mục 4 và [kế hoạch thực hiện](05_KE_HOACH_TOI_UU.md): phục hồi dữ liệu; timeout; autosave; xáo/ID câu; PIN; migration; ôn sai; giữ preview; tải/truy cập mobile; nghiệm thu và deploy có bằng chứng thật.

## 8. Tài liệu bàn giao

- [Kiến trúc và bảo mật](02_KIEN_TRUC_VA_BAO_MAT.md)
- [UI/UX và luồng thao tác](03_UI_UX_VA_LUONG_THAO_TAC.md)
- [Hiệu năng và dữ liệu: phương pháp, 3 mẫu, nguyên nhân](04_HIEU_NANG_VA_TRUY_XUAT_DU_LIEU.md)
- [Kế hoạch 4 giai đoạn, 10 ưu tiên và 34 ca bổ sung](05_KE_HOACH_TOI_UU.md)
- [Bằng chứng và cách chạy lại](evidence/INDEX.md)

Chỉ đánh dấu sẵn sàng sau khi đóng P0/P1, chạy hồi quy đúng build, có staging/deploy/backup và nghiệm thu thực tế phù hợp phạm vi. Đợt này hoàn thành kiểm toán và lập phương án, chưa triển khai các phương án sửa.
