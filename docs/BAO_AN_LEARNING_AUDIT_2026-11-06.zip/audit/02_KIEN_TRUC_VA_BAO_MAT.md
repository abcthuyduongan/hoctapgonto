# Kiến trúc và bảo mật — kiểm toán 06/11/2026

## 1. Phạm vi và công nghệ thực tế

Đối tượng là **Bảo An Learning 4.0.1**, source ID `59d67c93a8c3dd8839db1091c8760329f8d11c63984761ee5fe8342833bdff77`, trên HEAD `f7c93337669379d768419ae1ab43cbde69f2aabe` có nhiều thay đổi chưa commit. Giữ nguyên các thay đổi của chủ dự án. Đợt này chỉ đọc, chạy build/test và tạo tài liệu, chương trình kiểm tra, bằng chứng; không sửa mã sản phẩm.

Prompt có TKB, sơ đồ ghế, điểm danh, GVCN/GVBM và nhận xét liên tiết. Các phân hệ này **không tồn tại trong mã hiện tại, KHÔNG ÁP DỤNG**. Vai trò thật là `admin`, `student`, `parent`; quản lý/giáo viên dùng luồng quản trị học liệu. Không đánh giá thiếu phân hệ TKB như một lỗi của ứng dụng học tập.

```mermaid
flowchart TD
  B[Trình duyệt: React 19 + TypeScript] --> S[OnlineScreen: phiên và vai trò]
  S --> A[OnlineAdminDashboard: lớp, học liệu, quà]
  S --> C[OnlineStudentWorld: bản đồ, bài, ví, thi thử]
  S --> P[ParentPortalScreen: PIN, báo cáo, giới hạn]
  C --> G[Game và màn phụ tải theo nhu cầu]
  A --> API[online-client: REST cùng origin, cookie, CSRF, deadline]
  G --> API
  P --> API
  API --> LOCAL[Node HTTP: online-server]
  API --> CLOUD[Netlify Functions: cloud-api]
  LOCAL --> SQLITE[OnlineStore: SQLite]
  CLOUD --> PG[PostgresStore: pg, schema bao_an]
  CLOUD --> STORAGE[Supabase Storage private]
```

Vite dựng client; Node chạy HTTP/SQLite cục bộ; cloud dùng `pg` và Supabase SDK **ở máy chủ**. Không dùng Supabase Auth trong trình duyệt. `OnlineScreen` lazy load các màn theo vai trò; game được tải theo nhu cầu. Manifest có chế độ standalone nhưng worker hiện tại xóa cache cũ và tự unregister; không được quảng bá khả năng học online hoàn chỉnh khi mất mạng chỉ vì có PWA manifest.

## 2. Những nền tảng đang làm đúng

- Câu trả lời thô được gửi tới máy chủ, sao được cấp theo sổ cái và quy tắc tối đa; không dựa vào cờ `correct` do trình duyệt tự khai.
- Nội dung/phiên được ghim phiên bản; học lại chỉ cộng phần chênh lệch; có kiểm thử nhiều loại câu, lỗi ACK, đồng hồ và nghe âm thanh.
- Cookie phiên, CSRF, giới hạn body, DTO và kiểm tra workspace đã hiện diện. Mã mới đã thêm kiểm tra liên kết phụ huynh và elevation token ràng buộc phiên.
- API dữ liệu xác thực dùng private/no-store và Vary Cookie; media vẫn kiểm tra quyền trước cache. Cache Storage có giới hạn byte/số tệp/thời gian và gộp tải đang chạy.
- Client có timeout tới bước đọc body, AbortController, generation guard ở nhiều luồng, loader có retry. Đây là nền thích hợp để sửa theo lớp, **không cần viết lại toàn bộ**.
- Quản trị đã phân trang và gom truy vấn số dư; đo riêng SQLite với 23 lớp/1.000 học sinh không cho thấy nhu cầu tải toàn bộ danh sách lên giao diện.

## 3. RLS và ranh giới tin cậy

Mô hình hiện tại chặn các vai trò browser `anon/authenticated` bằng REVOKE/RLS, còn runtime PostgreSQL dùng tài khoản máy chủ có quyền owner/bypass; quyền theo người dùng và workspace được thực hiện tại store/API. Vì vậy bật RLS không tự bù được một hàm server thiếu kiểm tra quyền.

Đã đọc SQL và chạy logic qua fixture PostgreSQL/PGlite; **CHƯA KIỂM CHỨNG** cấu hình role, private bucket, policy và secret trên Supabase production thực tế. Không đọc/in `.env` hay service key trong đợt kiểm toán. Trước phát hành cần chạy kiểm tra quyền bằng tài khoản triển khai thật trong staging, xác minh browser không thể đọc bảng/bucket riêng và backend không vượt workspace.

## 4. Các vấn đề bảo mật và dữ liệu

Các mã dưới đây là mã của đợt 06/11, không thay thế lịch sử L01–L14. Các ca tái hiện chạy trên DB thử. PASS của chương trình tái hiện có nghĩa hành vi lỗi được xác nhận.

### A01 — P0: khôi phục SQL và media không nguyên tử

1. **Vị trí:** `server/cloud-backup-restore.mjs:132–186`.
2. **Hiện trạng:** SQL được commit trước khi upload/kiểm tra media hoàn tất.
3. **Bằng chứng:** inject lỗi Storage trong restore; hàm ném lỗi, nhưng tên workspace đích đã đổi từ `TARGET NEWER DATA` thành dữ liệu bản sao. JSON `evidence/security-reproductions-401.json`, ca `restore-nonatomic-storage-failure`.
4. **Nguyên nhân:** giao dịch chỉ bao phần SQL, không có staging/compensation cho object storage và không giữ trạng thái phục hồi rõ ràng.
5. **Ảnh hưởng:** quản trị thấy restore thất bại trong khi dữ liệu thật đã bị thay một phần; có nguy cơ mất dữ liệu mới hơn và media không khớp.
6. **Sửa:** kiểm tra toàn bộ trước khi ghi; upload vào vùng tạm có phiên restore, xác minh bytes/hash, rồi chuyển dữ liệu theo quy trình có điểm commit và phục hồi được; có snapshot đích và cleanup/compensation khi bước sau lỗi. Không chỉ di chuyển một lệnh COMMIT mà bỏ qua lỗi ở phía còn lại.
7. **Kỳ vọng:** mỗi lần restore có trạng thái xác định; thất bại giữ đích cũ hoặc khôi phục lại đích cũ được chứng minh; không báo thành công một phần.
8. **Rủi ro sửa:** Storage và SQL không chung transaction; thiếu cleanup gây tệp mồ côi, rollback sai có thể xóa tệp còn dùng. Cần ID restore và manifest riêng.
9. **Nghiệm thu:** lỗi ở từng bước trước/sau upload/commit, restart giữa quy trình, đích đang có dữ liệu, tệp trùng, đọc lại media và đối chiếu từng bảng. Dùng staging và bản sao, không thử phá production.

### A02 — P1: dry-run và restore báo hợp lệ/thành công khi chưa đủ điều kiện

1. **Vị trí:** `server/cloud-backup-restore.mjs:120–127,183–208`.
2. **Hiện trạng:** dry-run chủ yếu kiểm tra checksum bao ngoài; restore không có Storage uploader vẫn trả số media phục hồi/hash match.
3. **Bằng chứng:** payload thiếu bảng/media sai hash nhưng checksum envelope đúng vẫn `valid:true`; `targetStorage:null` vẫn `success:true, mediaRestored:1, mediaHashMatch:true`.
4. **Nguyên nhân:** nhầm tính toàn vẹn envelope với đầy đủ/hợp lệ dữ liệu, và dùng số lượng dự kiến thay số upload/readback thực.
5. **Ảnh hưởng:** quản trị có thể tin vào bản sao chưa phục hồi được; các diễn tập cho kết quả tốt giả.
6. **Sửa:** schema/manifest versioned, kiểm tra tập bảng/khóa ngoại/kích thước/hash trước ghi; thiếu uploader khi có media là lỗi; readback mới xác nhận phục hồi.
7. **Kỳ vọng:** VALID/SUCCESS chỉ xuất hiện khi mọi điều kiện tương ứng đã được kiểm tra và có số thực tế.
8. **Rủi ro:** backup cũ cần chuyển đổi có kiểm soát; không mặc định thiếu bảng là bảng rỗng.
9. **Nghiệm thu:** missing table, sai size/hash, tệp rỗng, uploader null, upload nửa chừng, sai phiên bản và backup cũ; đích không đổi khi preview bị từ chối.

### A03 — P1: xuất backup không cùng snapshot dữ liệu

1. **Vị trí:** `server/cloud-backup-restore.mjs:45–58`.
2. **Hiện trạng:** các bảng được SELECT độc lập khi ứng dụng còn ghi.
3. **Bằng chứng:** chèn một giao dịch tạo play+attempt giữa hai SELECT; backup có **0 plays, 1 attempt**, checksum hợp lệ; restore lỗi khóa ngoại.
4. **Nguyên nhân:** không dùng cùng kết nối/giao dịch snapshot nhất quán hoặc khóa/điểm cắt nghiệp vụ phù hợp.
5. **Ảnh hưởng:** backup tạo thành công nhưng không khôi phục được; quan hệ ví/attempt/award có thể thuộc các thời điểm khác nhau.
6. **Sửa:** snapshot nhất quán trên một transaction/kết nối, hoặc cơ chế điểm cắt được thiết kế rõ; metadata media và object bytes phải được đối soát trong cùng chính sách bất biến.
7. **Kỳ vọng:** hoạt động học tiếp tục mà backup vẫn nhất quán và phục hồi được.
8. **Rủi ro:** transaction dài tăng tài nguyên; cần giới hạn thời gian, theo dõi và chính sách retry, không khóa trường học quá lâu.
9. **Nghiệm thu:** đồng thời tạo attempt/award/redemption/parent link khi export; restore vào DB sạch, đối chiếu invariant và FK, lặp ở staging thật.

### A04 — P1: bỏ qua khóa PIN qua đường đổi PIN

1. **Vị trí:** `server/online-store.mjs:966–983`, `server/postgres-store.mjs:1154–1171`; tuyến `setup-pin` ở hai adapter.
2. **Hiện trạng:** `oldPin` được kiểm tra riêng, không dùng bộ đếm/khóa của `verify-pin`.
3. **Bằng chứng:** verify đã khóa, PIN đúng qua verify nhận 429. Trong lúc khóa, 20 lần oldPin sai qua setup nhận 403 nhưng không lần nào 429; oldPin đúng vẫn đổi PIN thành công. Tái hiện cả SQLite và PostgreSQL adapter.
4. **Nguyên nhân:** cùng bí mật có nhiều đường xác minh nhưng chỉ một đường áp dụng lockout.
5. **Ảnh hưởng:** cơ chế chống dò PIN không bảo vệ toàn bộ bề mặt thử PIN; người có phiên học sinh có thể bỏ qua giới hạn dự định.
6. **Sửa:** dùng chung verifier nguyên tử và chính sách khóa cho mọi tuyến nhận PIN, hoặc chỉ đổi PIN sau elevation hợp lệ; phân biệt quyền quản trị và người dùng thường rõ ràng.
7. **Kỳ vọng:** không còn tuyến thử PIN không giới hạn; thông báo hết hạn/khóa đúng trên UI.
8. **Rủi ro:** khóa nhầm admin hoặc tăng fail count không nguyên tử khi song song; cần test cả hai backend.
9. **Nghiệm thu:** verify→setup, setup→verify, song song, PIN đúng lúc khóa, hết khóa, logout/đổi mật khẩu/đổi PIN, token khác phiên/học sinh.

### A05 — P1: migration SQLite không an toàn khi bị gián đoạn

1. **Vị trí:** `server/online-store.mjs:46–59`.
2. **Hiện trạng:** CREATE/copy/DROP/RENAME để mở rộng role không được gói đầy đủ trong transaction và có `catch {}`.
3. **Bằng chứng:** mô phỏng restart sau khi tạo `users_upgrade_v4` trước copy; constructor chấp nhận khởi động, ràng buộc role cũ còn nguyên; tạo parent vẫn lỗi CHECK.
4. **Nguyên nhân:** không có lịch sử trạng thái migration và phục hồi/idempotency cho bảng tạm; lỗi bị nuốt.
5. **Ảnh hưởng:** máy dùng dữ liệu cũ có thể chạy với schema dở; rủi ro cao hơn tại điểm gián đoạn gần DROP/RENAME.
6. **Sửa:** migration có phiên bản, giao dịch và backup; kiểm tra trạng thái bảng tạm; tiếp tục/rollback an toàn; fail-fast nếu không bảo đảm dữ liệu; kiểm tra FK sau cùng.
7. **Kỳ vọng:** cài mới và nâng cấp cho kết quả tương đương, restart không làm mất tài khoản hay giữ schema thiếu.
8. **Rủi ro:** thay users ảnh hưởng toàn bộ FK; SQLite pragma/transaction cần diễn tập trên bản sao đúng phiên bản.
9. **Nghiệm thu:** lỗi/restart sau từng bước, chạy lại hai lần, dữ liệu user/student/session/award cũ, `foreign_key_check`, tạo parent và đăng nhập lại.

### A06 — P1 vận hành: chưa có đường cloud backup/restore hoàn chỉnh cho người quản trị

- **Vị trí/hiện trạng:** tìm lời gọi `exportCloudBackup/restoreCloudBackup` trong mã chỉ thấy module và hai tệp test, chưa thấy CLI/API vận hành gọi chúng.
- **Bằng chứng/nguyên nhân:** có chức năng mức thư viện và kiểm thử nhưng thiếu quy trình người vận hành, môi trường đích và báo cáo diễn tập thật.
- **Ảnh hưởng:** không thể coi đã có diễn tập cloud thực tế chỉ từ test thư viện.
- **Sửa/kỳ vọng:** thêm CLI hoặc luồng quản trị có phân quyền, preview/xác nhận đúng đích, manifest, khóa job và log; dựng diễn tập staging. Người quản trị thực hiện được quy trình đã viết.
- **Rủi ro:** thao tác phục hồi có khả năng thay dữ liệu; không mở endpoint công khai hoặc nhận target tùy ý.
- **Nghiệm thu:** vận hành từ đầu tới cuối trên staging, sai quyền/đích/backup bị từ chối, lưu kết quả và readback.

## 5. Nợ kỹ thuật và cấu trúc đề xuất

Inventory đo được 155 tệp mã/CSS trong src/server/tools, khoảng 1,96 MB nguồn. `postgres-store.mjs` khoảng 2.045 dòng, `online-store.mjs` 1.848 dòng; CSS game khoảng 4.292 dòng; TownScreen và ParentPortal cũng lớn. Kích thước không tự là lỗi, nhưng các chính sách PIN, chấm câu và backup đang có nhiều đường riêng dễ lệch.

Đề xuất tách dần khi sửa, giữ public contract và chạy chung kiểm thử hợp đồng:

```text
server/domain/       quyền phụ huynh, phiên trình bày câu, invariant sao
server/services/     thi thử, sao lưu, xuất đáp án, publish học liệu
server/stores/       SQLite/PostgreSQL: truy vấn và transaction
server/http/         adapter Node/Netlify, validate request, cookie/CSRF
src/features/        màn và state theo học liệu/phụ huynh/thi thử
```

Đây là hướng tổ chức, không yêu cầu di chuyển hàng loạt tệp trước khi sửa lỗi. Ưu tiên một chính sách quyền/ánh xạ chung với kiểm thử tương đương hai backend; không đưa toàn bộ query vào một abstraction mới chưa cần thiết.

`supabase/verify.sql` còn danh sách 16 bảng trong khi setup/check mới dùng 29 bảng: cập nhật cùng manifest migration, tránh các công cụ kiểm tra cho kết quả khác nhau. Runtime cloud có pool nhỏ; tác động queue/cold-start thực tế **CHƯA KIỂM CHỨNG**, không tự tăng kết nối khi chưa đo giới hạn DB và mô hình chạy functions.

## 6. Đối chiếu báo cáo 4.0.1

Đường bypass settings không PIN và ghi vào trẻ chưa liên kết đã được sửa ở mã mới; DTO đã loại hash/salt; backup đã thêm hai bảng thiếu và export fail-fast; setup đã nạp tám migration. Đây là tiến bộ thực tế. Các lỗi mới ở trên cho thấy phải kiểm tra toàn bộ đường đi và điều kiện lỗi, không chỉ happy path.

Không dùng “0 pass, 7 fail” của chương trình tái hiện cũ làm bằng chứng mọi lỗi đã triệt tiêu: bài có thể dừng sớm do setup/hợp đồng đã đổi. Cần kiểm thử hồi quy an toàn có negative/positive rõ và ca lỗi cưỡng bức như đợt này. Xem [kế hoạch ưu tiên](05_KE_HOACH_TOI_UU.md) và [bằng chứng tổng hợp](evidence/INDEX.md).
