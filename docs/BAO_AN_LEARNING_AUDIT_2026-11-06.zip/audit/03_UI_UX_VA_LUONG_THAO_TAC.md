# UI, UX và luồng thao tác — kiểm toán 06/11/2026

## 1. Các hành trình thực tế

Ứng dụng có quản trị/giáo viên, học sinh và phụ huynh. Các hành trình TKB, sơ đồ ghế, điểm danh, GVCN/GVBM trong prompt không có ở dự án này và được ghi KHÔNG ÁP DỤNG. Không thêm các phân hệ đó như một yêu cầu nâng cấp ngầm.

| Nhóm | Luồng hiện tại cần kiểm tra | Luồng đích sau sửa |
| --- | --- | --- |
| Quản lý/giáo viên | Đăng nhập → chọn lớp → nhập Word/Excel/media → preview → kiểm tra → xuất bản → kiểm tra bài/đáp án | Giữ lớp, tệp và preview khi đổi tab trình duyệt; dữ liệu nền được làm mới mà không xóa bản nháp; chỉ xuất bản sau kiểm tra |
| Học sinh | Đăng nhập → bản đồ/vùng → bộ được giao → chơi → sai/làm lại → lưu sao → thoát → bài tiếp/quà | Mỗi lượt hiển thị có ID; lựa chọn/chấm/feedback cùng ánh xạ; lỗi mạng không đổi lựa chọn; quay lại giữ điều hướng hợp lý |
| Thi thử | Chọn dạng → làm bài/autosave → hết giờ hoặc nộp → kết quả → ôn sai | Autosave có thứ tự, hết giờ dùng đáp án mới nhất; ôn sai thực sự tạo và mở bài ôn |
| Phụ huynh | Đăng nhập hoặc vào khu PIN → chọn con → báo cáo/giới hạn/quà → xác nhận | Quyền và khóa PIN nhất quán mọi tuyến; hết hạn hướng dẫn rõ; không truy cập trẻ chưa liên kết |
| Quản trị dữ liệu | Sao lưu → kiểm tra bản sao → chọn đích → phục hồi → đối soát | Trạng thái thật, preview kiểm tra đầy đủ, lỗi không để dữ liệu dở; cloud có đường vận hành cụ thể |

## 2. Những lỗi thao tác đã tái hiện

### U01 — P1: thi thử hết giờ có thể xóa đáp án đã lưu

1. **Vị trí:** `src/screens/ContestMockScreen.tsx:93–119`; `server/online-store.mjs:1380`, `server/postgres-store.mjs:1572`.
2. **Hiện trạng:** callback interval đóng trên state `answers` lúc bắt đầu, thường là `{}`; nộp hết giờ có thể dùng state cũ.
3. **Bằng chứng:** component TSX hiện tại, actual SQLite store và adapter thử; thời gian UI được ép 3 giây để tái hiện xác định. Trước timeout đã autosave `{vm3_07:'21'}` đúng; timeout gửi `{answers:{}}`; DB cuối rỗng và điểm/câu đúng bằng 0. Xem `evidence/contest-timeout-reproduction.json` và ảnh kết quả.
4. **Nguyên nhân:** effect phụ thuộc phiên/mode nhưng hàm nộp dùng closure state ban đầu; server ưu tiên object input thay phần đã lưu.
5. **Ảnh hưởng:** học sinh làm bài đúng vẫn bị mất đáp án/điểm khi hết giờ.
6. **Sửa:** timeout dùng state/ref mới nhất và cơ chế nộp idempotent; ưu tiên chấm trên đáp án đã commit, đồng bộ các autosave đang chạy theo hợp đồng chốt bài. Server không nhận một object cũ/rỗng để vô tình xóa bài đã lưu.
7. **Kỳ vọng:** hết giờ và nộp thủ công cho cùng tập đáp án đã xác nhận thì cùng kết quả.
8. **Rủi ro sửa:** nộp trùng khi timeout trùng nút bấm, đáp án đến sau deadline, câu chưa ACK. Cần quy tắc server rõ.
9. **Nghiệm thu:** trả lời rồi để hết giờ; sửa câu sát giờ; chờ autosave; lỗi mạng; timeout+nộp cùng lúc; reload; đối chiếu DB và kết quả cả hai backend.

### U02 — P1: autosave thi thử đến muộn ghi đè đáp án mới

1. **Vị trí:** `ContestMockScreen.tsx:155–178` và hàm lưu đáp án thi thử trong hai store.
2. **Hiện trạng:** gửi object đáp án nguyên bộ bất đồng bộ, không có revision/serialization; lỗi bị `.catch(()=>{})`.
3. **Bằng chứng:** giữ request đầu chậm 900 ms; UI đã chọn hai câu, store nhận `{q1,q2}` rồi `{q1}`; DB cuối mất q2. Xem `evidence/contest-autosave-reproduction.json`.
4. **Nguyên nhân:** giả định thứ tự hoàn thành request luôn bằng thứ tự nhập; không có ràng buộc phiên bản cập nhật.
5. **Ảnh hưởng:** dữ liệu lưu không khớp giao diện; lỗi xảy ra dễ hơn khi mạng yếu, không hiện cảnh báo.
6. **Sửa:** cập nhật có revision/sequence được server kiểm tra hoặc serialize/coalesce có ACK; patch theo câu với phiên bản phù hợp. UI hiện đang lưu/đã lưu/chưa lưu và có retry chính xác.
7. **Kỳ vọng:** response cũ không thể thay đáp án mới; người dùng biết dữ liệu nào đã được xác nhận.
8. **Rủi ro:** nhiều tab, reconnect, submit trong khi save pending; không giải quyết bằng debounce đơn thuần.
9. **Nghiệm thu:** đảo thứ tự request, timeout, retry, hai tab, sửa/xóa đáp án chủ ý, nộp lúc có request chờ và deadline.

### U03 — P1: client không ràng buộc ID của lượt câu hỏi, có thể chấm sai nội dung đúng

1. **Vị trí:** `src/core/online-client.ts:110`, hợp đồng AttemptInput/QuestionOpen và các game; kiểm tra optional `presentationId` tại `online-store.mjs:414`, `postgres-store.mjs:572`.
2. **Hiện trạng:** máy chủ đã sinh hoán vị/ID nhưng game và client không gửi ID; nút “Trả lời lại” chỉ xóa feedback, không mở lượt trình bày mới.
3. **Bằng chứng:** trên app build thật, sai→làm lại vẫn chỉ 1 lần `question-open`, lựa chọn không đổi. Sau khi client thứ hai mở hoán vị mới, UI cũ bấm nội dung đúng “2” của 1+1 nhưng máy chủ chấm sai; cả hai attempt body thiếu ID. `evidence/shuffle-client-reproduction.json`.
4. **Nguyên nhân:** triển khai xáo ở store chưa nối hợp đồng end-to-end; server chỉ kiểm tra ID khi request tự gửi.
5. **Ảnh hưởng:** sai điểm/sao và lời giải phản hồi trong tình huống nhiều tab/lượt; yêu cầu gọi lại phải đổi vị trí chưa đạt ở UI.
6. **Sửa:** đưa presentationId vào type/receipt/state và mọi request chọn đáp án; bắt buộc ở phiên giao thức mới. Lượt cũ bị thay thế nhận 409 và UI đồng bộ rõ; retry cùng attempt giữ hoán vị/ID, không xáo vì render. Lần làm lại mới sau sai phải được server cấp hoán vị theo yêu cầu chủ dự án.
7. **Kỳ vọng:** nội dung đúng luôn chấm đúng theo chính lựa chọn đang hiển thị; lượt mới đổi vị trí; lỗi mạng không đổi lựa chọn hoặc nhân sao.
8. **Rủi ro:** tương thích phiên cũ, feedback dùng chỉ số nguồn thay chỉ số hiển thị, đồng hồ/gợi ý bị reset. Không chỉ sửa một game rồi bỏ đọc/nghe/thi thử.
9. **Nghiệm thu:** UI thật, mọi đường trắc nghiệm, hai tab, stale ID, retry ACK, reload/restart, backup/restore, đúng/sai mọi vị trí, đồng hồ và tối đa 3 sao.

Phần lịch sử chống lặp cũng chưa bền: `online-store.mjs:110–136` và `postgres-store.mjs:46–72` dùng Map trong tiến trình và chỉ tìm 5 play gần nhất. Đã tái hiện trên cả hai backend: sau 5 lượt không liên quan, cache lạnh không tìm vị trí cũ; cache nóng không thấy vị trí mới ghi từ instance khác. RNG điều khiển được sinh lại đúng vị trí gần nhất, vi phạm yêu cầu gọi lại phải đổi vị trí. Đây là nguyên nhân dữ liệu/history bên cạnh lỗi hợp đồng UI. Sửa bằng lịch sử theo student/question/version lưu bền và đọc/cập nhật nguyên tử, không dùng Map làm nguồn quyết định cuối. Test cold-start, nhiều instance và >5 lượt xen kẽ là bắt buộc; bằng chứng `evidence/shuffle-history-reproduction.json`.

### U04 — P1: nút ôn câu sai chỉ quay về bản đồ

1. **Vị trí:** `OnlineStudentWorld.tsx:419–422`, `ContestMockScreen.tsx:191–198`, `server/contest-data.mjs:90–119`.
2. **Hiện trạng:** callback nhận `_pack` rồi bỏ qua; gói review còn dùng `kind:'choice'/choices`, khác hợp đồng quiz/multiple-choice/options.
3. **Bằng chứng:** nút ôn gọi review endpoint HTTP 200, có 15 items, rồi dialog đóng; không có learning dialog, số play trước/sau đều 1, không tạo lượt ôn. `evidence/contest-review-reproduction.json`.
4. **Nguyên nhân:** nối UI chưa hoàn tất và schema gói ôn chưa tương thích bộ chạy câu hỏi.
5. **Ảnh hưởng:** người học không thực hiện được lời hứa “Ôn các câu sai ngay”.
6. **Sửa:** chuẩn hóa gói ôn phía máy chủ, giữ câu/lời giải hợp lệ, tạo session ôn có quyền và mở game qua luồng chuẩn. Không tặng thêm sao ngoài quy tắc; không dùng các lựa chọn nhiễu giả có thể lộ ngay đáp án.
7. **Kỳ vọng:** một lần bấm mở được đúng tập câu sai và lưu kết quả đúng chính sách.
8. **Rủi ro:** nhầm nguồn/phiên bản, học sinh tự gửi pack có đáp án để cấp sao; phải tạo/validate ở server.
9. **Nghiệm thu:** có/không có câu sai, nhiều dạng câu, đủ media, quyền khác học sinh, tải lỗi, thoát/quay lại và không cấp sao trùng.

### U05 — P1: quay lại tab làm mất bản preview nhập học liệu

1. **Vị trí:** `src/screens/OnlineAdminDashboard.tsx:57,62`.
2. **Hiện trạng:** refresh thành công xóa preview/weekCheck/library; focus/visibility tự refresh khi quay lại tab.
3. **Bằng chứng:** app production build + SQLite HTTP fixture; preview 6/6 câu đang hiện, kích hoạt handler window focus; summary read tăng 2→3, preview count 1→0, chưa xuất bản tuần nào. Đây là event thử xác định, không phải quan sát giáo viên thật. `evidence/preview-focus-reproduction.json`, ảnh trước/sau.
4. **Nguyên nhân:** trộn làm mới dữ liệu nền với reset bản nháp thao tác cục bộ.
5. **Ảnh hưởng:** giáo viên chuyển sang tệp nguồn để kiểm tra rồi quay lại phải nhập/xem trước lại; dễ mất công và nghi ngờ đã lưu hay chưa.
6. **Sửa:** tách state draft/preview khỏi server summary; chỉ reset sau publish/hủy/chọn nguồn khác rõ ràng. Refresh có generation guard và kiểm tra phiên bản nguồn, báo khi dữ liệu nền đổi mà không hủy bản nháp.
7. **Kỳ vọng:** chuyển tab/lấy lại focus không làm mất công việc; vẫn cập nhật dữ liệu mới an toàn.
8. **Rủi ro:** giữ preview quá hạn, publish trên class/source cũ; phải buộc kiểm tra lại khi ý nghĩa dữ liệu đã thay đổi.
9. **Nghiệm thu:** preview→blur/focus, visibility, đổi lớp, phiên hết hạn, nguồn sửa, publish một lần và bấm liên tục; không tạo tuần trùng.

### U06 — P2: tương phản/ARIA có lỗi, bài a11y hiện tại quét màn chưa có nội dung

1. **Vị trí:** `src/screens/TownScreen.tsx:440,497`, màu ở `src/styles/learning-interface.css:5` và styles liên quan; `tests/visual/online-a11y.spec.ts:38–74`.
2. **Hiện trạng:** màu chữ trên nền tranh có tương phản thấp; grid thị trấn thiếu cấu trúc ARIA con; vùng cuộn và accessible name chưa nhất quán. Bài kiểm thử tắt contrast và không chờ nội dung thật.
3. **Bằng chứng:** axe mặc định trên app build Chrome 390×844 có map: 12 node contrast và 9 node label/name; town: 1 node `aria-required-children` mức critical theo axe, 71 node contrast, 1 vùng cuộn không focus được. Ví dụ chữ eyebrow 2,33:1 và dòng chào 2,68:1 so với yêu cầu 4,5:1 của chính phép quét. Reproduction bài a11y hiện hành: không có map, không có grid thị trấn trước/sau scan, chỉ có “Đang mở thị trấn của con…”, nên cả hai scan rỗng. `evidence/ui-accessibility-observation.json`, `evidence/a11y-scope-reproduction.json`.
4. **Nguyên nhân:** CSS màu nhạt và ARIA chưa đúng; fixture không giao tuần; điều kiện đợi match chuỗi trong Suspense fallback, không xác nhận nội dung đã tải.
5. **Ảnh hưởng:** khó đọc trên điện thoại/ngoài trời, dùng công nghệ hỗ trợ hoặc bàn phím gặp khó; báo cáo tự động tạo cảm giác đã kiểm tra dù màn chính chưa được quét.
6. **Sửa:** token màu đạt tương phản trong trạng thái thực; dùng grid/row/gridcell đúng hoặc semantics đơn giản phù hợp; vùng cuộn có đường bàn phím; tên nhìn thấy nằm trong accessible name. Bài test phải có dữ liệu và đợi map/grid/API ổn định, bật contrast; zoom thật kiểm riêng.
7. **Kỳ vọng:** cùng nhiệm vụ dùng được bằng nhìn/chạm/bàn phím; quét tự động phản ánh đúng màn sử dụng.
8. **Rủi ro:** chỉnh CSS ảnh hưởng mọi game, ARIA giả làm UX khó hơn; không đổi severity axe thành P0 sản phẩm một cách máy móc. Kiểm tra cả giao diện sau sửa.
9. **Nghiệm thu:** axe với dữ liệu đầy đủ ở ba khổ; bàn phím/focus/vùng cuộn, screen-reader phù hợp, zoom trình duyệt 200% và tăng font; ảnh trước/sau. Các phép đo trên là browser giả lập viewport, không phải thiết bị vật lý.

## 3. Đánh giá theo màn hình

| Màn | Điểm tốt quan sát từ mã/test | Cần xử lý hoặc giới hạn |
| --- | --- | --- |
| Kết nối/đăng nhập/khởi tạo | Có state loading/unavailable và retry; không tải màn admin/student trước khi biết vai trò | Đo cold/warm và ảnh ở mục hiệu năng; nhập liệu/focus/zoom thật cần nghiệm thu thiết bị |
| Quản trị lớp/học sinh | Có bộ lọc/lớp, phân trang, tạo tài khoản riêng | Giữ state khi chuyển tab; giảm reset bản nháp U05; kiểm tra label/vùng chạm bằng dữ liệu dài |
| Nhập Word/Excel/media | Có preview, lỗi từng dòng, batch upload và kiểm tra trước publish | Không xóa preview khi quay lại; lỗi nhiều tệp cần giữ tệp tốt và chỉ rõ chưa publish |
| Bản đồ/vùng/hành trình | Tranh nhẹ, không engine 3D; có kiểm thử hình học ba khổ; đã sửa bộ chọn/thu mở hành trình | Nút vào bài, trạng thái hành trình sau thoát phải nhất quán; tên dài và quá nhiều hành động phụ cần thử người dùng |
| Trò chơi và kết quả | Có khóa trong khi lưu, deadline, ACK, retry chính xác ở nhiều trò | Hoàn thiện presentationId U03; kiểm tra correctIndex feedback theo hiển thị; không bỏ sót game mới |
| Ví/kệ quà/mục tiêu/huy hiệu | Có luồng và kiểm thử tự động | Quyền parent và phục hồi phải bảo toàn; không suy ra động lực học thực tế từ kiểm thử kỹ thuật |
| Thị trấn/bảng tin | Có màn riêng, giới hạn tương tác và vật liệu | Component/CSS lớn; kiểm tra tải theo nhu cầu, focus, bàn phím và chạm trên màn nhỏ |
| Phụ huynh/báo cáo | Có elevation token, chọn con, giới hạn và DTO mới | Khóa PIN mọi tuyến A04; a11y/zoom và nội dung báo cáo cần người thật xác nhận |
| Thi thử/ôn sai | Có đề, thời gian và kết quả | U01–U04 chặn nghiệm thu luồng đầy đủ, dù bài happy path nộp thủ công có thể PASS |
| Sao lưu/phục hồi | Local có panel preview/confirm | Cloud chưa có đường vận hành đầy đủ; A01–A03 không cho phép xác nhận dữ liệu an toàn |

Bảng này không tuyên bố mọi pixel/trạng thái đã được người dùng thật nghiệm thu. Các ảnh và quét tự động từ đợt này được liệt kê tại [bằng chứng](evidence/INDEX.md); số đo truy cập/viewport ở [báo cáo hiệu năng](04_HIEU_NANG_VA_TRUY_XUAT_DU_LIEU.md).

## 4. Hướng thống nhất thiết kế

Giữ phong cách bản đồ/tranh và nhân vật biểu tượng nhẹ hiện có. Chuẩn hóa một bộ token màu, font, khoảng cách, border, focus, trạng thái disabled/loading/error/success; dùng lại button/dialog/form/status thay vì từng màn tự làm. Không làm lại toàn bộ CSS khi chưa có ảnh đối chiếu và ca hồi quy.

Trên điện thoại: một hành động chính rõ cho mỗi màn; lớp/tuần đã biết nên được giữ; thao tác phụ gom vừa phải; thông báo “đã lưu” chỉ sau ACK; “chưa lưu” phải có retry. Kiểm tra vùng chạm theo kích thước thực và ngữ cảnh, không đồng nhất mục tiêu 44 px với mọi tiêu chí WCAG. Tên dài, lỗi dữ liệu, offline và bàn phím màn hình phải được thử riêng.

Quản trị ưu tiên nhận biết trạng thái nguồn → preview → kiểm tra → đã xuất bản. Học sinh ưu tiên học tiếp → phản hồi → tiến độ. Phụ huynh ưu tiên đúng con → quyền hợp lệ → thay đổi → xác nhận. Luồng chỉ thêm xác nhận ở thao tác thay dữ liệu quan trọng; không đặt hộp hỏi cho mọi nút chuyển màn.

## 5. Kiểm tra tiếp sau sửa

- Tự động: các reproduction trên chuyển thành hồi quy an toàn trong tests chuẩn, kiểm tra cả UI và DB; cố tình đảo thứ tự request/giữ ACK, không chỉ mock đáp án thành công.
- Mobile: 390×844, 768×1024, 1440×900; Chrome/Edge; vuốt/chạm thật, focus sau dialog, tên dài và dữ liệu nhiều tuần.
- Truy cập: bật contrast, zoom trình duyệt 200%, tăng font thiết bị, bàn phím và thông báo trạng thái. Các mục chưa có dữ liệu thật ghi **CHƯA KIỂM CHỨNG**.
- Người dùng: giáo viên thực hiện nhập/preview/publish khi đứng lớp; học sinh tự học 15 phút; phụ huynh đổi giới hạn/quà. Không thay bằng kịch bản mô phỏng hoặc tự sinh phỏng vấn.
