# Hiệu năng và truy xuất dữ liệu — 06/11/2026

## 1. Phương pháp và phạm vi

Đã đo trên **production build 4.0.1**, không dùng Vite dev server. Công cụ: Chrome headless, Playwright, CDP, PerformanceObserver/Resource Timing, CSS coverage, HTTP server thật trên localhost và SQLite dữ liệu thử. Đo sau khi toàn bộ suite nặng đã kết thúc. Script và dữ liệu thô trong [evidence](evidence/INDEX.md).

| Thuộc tính | Điều kiện thực tế |
| --- | --- |
| Máy | Windows; Intel Core Ultra 5 125H; 18 CPU logic; RAM 31,4 GiB; Node 22.22.2 |
| Desktop | Viewport 1440×900; không làm chậm CPU/mạng bổ sung |
| Điện thoại giả lập | 390×844, touch/mobile; CDP CPU slowdown ×4 |
| Mạng giả lập hạn chế | Cấu hình CDP latency 150 ms; download 1,6 Mib/s; upload 750 Kib/s; không mất gói |
| Số lần | 3 lần/profile/kịch bản, tổng 54 mẫu thao tác/điều hướng |
| Cold | Xóa HTTP browser cache trước điều hướng; không phải cold-start máy chủ/cloud |
| Warm | Điều hướng lại trong cùng context, không xóa cache |
| Dữ liệu browser | 23 lớp, 1.000 học sinh giả lập, 8 tuần/lớp; 12 câu trong gói dùng chung; không phải 1.000 người đồng thời |
| Sẵn sàng | Locator nghiệp vụ hiển thị, ảnh đang thấy trong viewport tải xong; game có lựa chọn được bấm; trả lời có ACK hiển thị |
| Cách lấy mẫu | Snapshot sau mốc sẵn sàng 650 ms; `usableMs` loại thời gian chờ 650 ms, còn overhead nhỏ của phép đo |

LCP/CLS là **giá trị quan sát trong cửa sổ lab**, không phải p75 thực địa. FCP/LCP của điều hướng là của document đó; không dùng lại giá trị navigation để gọi là LCP của thao tác SPA. Resource count/byte của thao tác là lũy kế từ document, không phải toàn bộ đều tải lại khi bấm nút.

TTFB lấy `requestStart→responseStart` của localhost: phản ánh stack cục bộ và cách CDP ghi timing, không phải RTT hay latency Supabase/Netlify. Byte `encodedBodySize` là body tài nguyên; khác transfer bytes có header và khác byte thật đi lại khi cache. Gzip trong bảng bundle là nén cục bộ, không mặc định bằng byte giao qua CDN.

Lượt đầu mỗi profile còn chụp ảnh/quét axe trước vài thao tác; trạng thái prefetch/cache của thao tác game có thể khác các lượt sau. Vì vậy giữ đủ ba mẫu và không suy ra SLA/p95 từ ba mẫu nhỏ. Mọi lần điều hướng vẫn được thực hiện theo profile nêu trên.

## 2. Kết quả ba lần: thời gian tới mốc sẵn sàng

Đơn vị **ms**, lần 1 / lần 2 / lần 3; không thay số xấu bằng trung bình.

| Kịch bản | Desktop localhost | Điện thoại 4G hạn chế giả lập |
| --- | --- | --- |
| Đăng nhập — cold load | 957,7 / 966,4 / 940,1 | 2590,0 / 2580,5 / 2531,8 |
| Đăng nhập — warm load | 382,8 / 382,3 / 382,2 | 1379,1 / 1450,0 / 1251,9 |
| Bấm đăng nhập quản trị → dùng được | 898,5 / 887,8 / 900,4 | 1486,3 / 1493,7 / 1481,2 |
| Khôi phục phiên quản trị, cold cache | 951,2 / 911,8 / 933,1 | 4046,1 / 3985,7 / 4045,2 |
| Quản trị → Học liệu tuần | 65,8 / 86,5 / 83,1 | 395,6 / 303,6 / 313,8 |
| Khôi phục phiên học sinh, cold cache | 972,7 / 946,2 / 887,6 | 4668,7 / 4712,2 / 4478,6 |
| Học sinh → game, lựa chọn bấm được | 964,2 / 973,0 / 1014,2 | 3851,4 / 3581,5 / 3498,4 |
| Chọn đáp án đúng → nhận ACK hiển thị | 89,7 / 95,6 / 82,6 | 417,8 / 434,1 / 454,8 |
| Thoát game → dialog đóng | 66,0 / 98,8 / 66,7 | 461,4 / 388,6 / 362,4 |

Không có exception/pageerror được harness ghi nhận trong 54 mẫu này. Điều đó không bác bỏ các race condition tái hiện riêng trong thi thử/xáo đáp án; chuỗi đo tốc độ chỉ đi qua một câu trả lời đúng thông thường.

## 3. FCP, LCP, CLS, TTFB và INP

### 3.1. Điều hướng điện thoại giả lập

| Màn | FCP ba lần (ms) | LCP quan sát ba lần (ms) | CLS ba lần | TTFB localhost ba lần (ms) |
| --- | --- | --- | --- | --- |
| Đăng nhập cold | 1652 / 1652 / 1656 | 2172 / 2120 / 2156 | 0,2798 / 0,2798 / 0,2798 | 3,0 / 2,4 / 2,2 |
| Đăng nhập warm | 408 / 452 / 324 | 692 / 736 / 640 | 0,2324 / 0,2324 / 0,2324 | 9,0 / 2,9 / 1,8 |
| Quản trị cold | 1556 / 1540 / 1568 | 3256 / 3224 / 3252 | 0,0960 / 0,0960 / 0,0960 | 2,0 / 3,3 / 2,1 |
| Học sinh cold | 1532 / 1564 / 1532 | 4684 / 4716 / 4500 | 0,1119 / 0,1119 / 0,1119 | 2,2 / 1,6 / 1,9 |

Ở desktop: LCP cold đăng nhập 464/436/432 ms; quản trị 676/688/688 ms; học sinh 1132/940/864 ms. CLS học sinh desktop là 0,4558 ở ba lượt; quản trị là 0,1233/0,1233/0,0500. Đăng nhập desktop CLS 0,0278.

Mục tiêu đối chiếu là LCP ≤ 2,5 s, CLS ≤ 0,1 và INP ≤ 200 ms. Các chỉ số cốt lõi có ý nghĩa thực địa; cần tách phép đo lab khỏi dữ liệu người dùng. [Google Search Central](https://developers.google.com/search/docs/appearance/core-web-vitals), [PageSpeed Insights: lab và field](https://developers.google.com/speed/docs/insights/v5/about).

**Kết luận giới hạn:** ở profile lab này, LCP quản trị/học sinh và CLS ở nhiều màn vượt mục tiêu tham chiếu. Chưa được gọi đó là kết quả Core Web Vitals production vì chưa có dữ liệu người dùng thực tế của bản 4.0.1.

### 3.2. INP

**INP thực địa: CHƯA KIỂM CHỨNG.** Harness lưu Event Timing có interactionId và long tasks, nhưng không triển khai đầy đủ phép tính INP theo vòng đời trang và không có mẫu người dùng đủ để kết luận p75.

Ví dụ khi chuyển sang học liệu trên profile mobile, duration tương tác lớn nhất quan sát là 248/192/208 ms. Đây là mẫu sự kiện lab, **không được đổi tên thành INP**. Cần bổ sung RUM phù hợp và thử tương tác thật trên thiết bị; không gửi nội dung câu hỏi, tên học sinh hay token vào analytics.

## 4. Network, bundle và coverage

| Mốc | Request ghi nhận | JS body | CSS body | Tổng body tài nguyên |
| --- | ---: | ---: | ---: | ---: |
| Đăng nhập cold | 8 | 245.002 B | 30.149 B | 345.322 B |
| Quản trị cold | 13 | 396.552 B | 33.061 B | 508.878 B |
| Học sinh cold, mobile | 18 / 17 / 15 | 330.180 B | 81.086 B | 819.321 / 755.079 / 633.488 B |
| Sau mở game, mobile, lũy kế | 32 | 347.912 B | 360.807 B | 1.368.560 B |
| Sau lưu câu/thoát game | 33 / 37 lũy kế | Xem JSON | Xem JSON | Xem JSON |

Tổng ở mốc sẵn sàng có thể khác do tài nguyên nền đang tải và lựa chọn kích thước/ảnh. Đây là ảnh chụp waterfall tại từng mốc, không phải chứng minh toàn bộ artifact đã tải xong.

Những request chậm đo được trên profile mobile, ví dụ các lượt 1–2:

| Tài nguyên | Body | Thời gian resource | Diễn giải |
| --- | ---: | ---: | --- |
| `GameCompletion-DfX71KsR.css` | 268.623 B | 2697 / 2756 ms | CSS chung lớn trên đường mở game |
| `map-math-wide.webp` | 222.302 B | 2256 / 2346 ms | Tranh nền game tải bằng CSS, cạnh tranh băng thông lúc mở |
| `index-BZ5IhaHK.js` | 226.351 B | khoảng 1253–1271 ms | Bundle nền phải tải/parse trước phần vai trò |
| `OnlineAdminDashboard-B4ZLRUVe.js` | 141.971 B | khoảng 1078–1099 ms | Màn quản trị đã tách chunk nhưng còn khá lớn |
| Các ảnh thẻ game khoảng 60–64 KB/tệp | 60–64 KB | khoảng 1117–1160 ms | Cần rà ưu tiên và thời điểm tải; không tự kết luận mọi ảnh là dư |
| `auth-welcome.webp` | 69.426 B | khoảng 738–750 ms trên admin cold | Được tải cả khi đang khôi phục phiên đã đăng nhập |

Gzip cục bộ: main JS 71.239 B, admin JS 46.913 B, student JS 23.875 B, CSS game 52.022 B. HTTP localhost của phép đo không đại diện cấu hình nén/CDN Netlify; không được hứa sản xuất chậm đúng bằng các số này.

CSS coverage sau đi qua bản đồ→quiz→thoát: `GameCompletion` có 268.613 ký tự stylesheet, sử dụng 38.654 ở desktop lượt 1 (**14,39%**) và 35.419 ở mobile lượt 1 (**13,19%**). Phần chưa được quan sát dùng **không đồng nghĩa có thể xóa toàn ứng dụng**: có thể phục vụ game/trạng thái khác. Cần tách theo game và chạy ảnh hồi quy mọi màn.

Artifact hiện tại: 113 tệp, 5,08 MiB, PASS theo giới hạn 8 MiB đang có. Baseline trước từng đặt 5 MiB; nếu vẫn giữ mục tiêu đó cần tối ưu hoặc quyết định sửa ngân sách rõ, không gọi hai tiêu chí là một.

## 5. Các nguyên nhân và giải pháp có thể kiểm chứng

### P01 — P1: CSS/tranh nền lớn trên đường mở game

1. **Vị trí:** `src/styles/game-base.css`, imports ở `OnlineExerciseRunner` và game; CSS game/nền bản đồ trong artifact.
2. **Hiện trạng:** CSS game 268 KB và tranh wide 222 KB tải trên đường chuyển game; trên mạng profile chậm mất khoảng 2,3–2,8 s cho từng tài nguyên.
3. **Bằng chứng:** Resource Timing, bytes và coverage ở mục 4; thời gian game-ready 3498–3851 ms mobile.
4. **Nguyên nhân:** stylesheet dùng chung chứa nhiều selector game/legacy; nền CSS cần tải/giải mã; các tài nguyên tranh cạnh tranh đường truyền. Tác động chính xác từng thành phần cần so A/B sau tách.
5. **Ảnh hưởng:** bấm vào game rồi chờ nhiều giây trên điện thoại hạn chế băng thông.
6. **Sửa:** tách shared primitives với CSS từng game, loại selector không dùng có bằng chứng, chọn ảnh phù hợp viewport, giữ kích thước/nền dự phòng; prefetch giới hạn và ưu tiên bài đang học.
7. **Kỳ vọng:** giảm byte trên đường tới game và thời gian sẵn sàng đo cùng profile; không hứa tỷ lệ tăng tốc khi chưa chạy bản sửa.
8. **Rủi ro:** cascade giữa game, cảnh nền, các trạng thái hint/result; xóa theo một lần coverage có thể hỏng màn khác.
9. **Nghiệm thu:** cùng 3 mẫu trước/sau, cold/warm rõ, mọi game/3 viewport, ảnh đối chiếu, media/ACK và budget không hồi quy.

### P02 — P2: tải ảnh đăng nhập khi khôi phục phiên, layout thay đổi đáng kể

1. **Vị trí:** `src/screens/OnlineScreen.tsx:29–30`, loading/auth layout, styles nhập muộn của các màn.
2. **Hiện trạng:** mọi phase chưa ready dùng layout auth có ảnh eager, kể cả phase loading khôi phục phiên; sau đó đổi sang role screen. CLS lab vượt 0,1 ở nhiều trường hợp.
3. **Bằng chứng:** code và request 69.426 B auth-welcome trong admin cold; CLS cụ thể mục 3.
4. **Nguyên nhân:** dùng màn chào có ảnh làm shell kết nối; đổi bố cục role và CSS bất đồng bộ là ứng viên gây layout shift. **Chưa tách đóng góp của từng node** vì chưa ghi trace source attribution; không quy toàn bộ CLS cho riêng ảnh này.
5. **Ảnh hưởng:** tải dữ liệu không cần cho người đã đăng nhập, nội dung nhảy vị trí khi sẵn sàng.
6. **Sửa:** shell kết nối nhẹ, chỉ tải ảnh auth khi thực sự vào login/setup; giữ vùng skeleton/kích thước ảnh, nạp styles cần thiết đúng lúc. Ghi attribution layout-shift để sửa đúng nguồn.
7. **Kỳ vọng:** ít request/byte hơn ở session restore, CLS giảm có đo trước/sau.
8. **Rủi ro:** flash màn đăng nhập/role cũ, hydration/layout sai, làm mất phản hồi kết nối; giữ cùng startup race tests.
9. **Nghiệm thu:** phiên có/không có, mạng chậm, status/me lỗi, cold/warm, ảnh/vùng chính ổn định và không rò màn vai trò sai.

### P03 — P1 công cụ nghiệm thu: runner tải thật báo thành công giả

1. **Vị trí:** `tools/staging_load_runner.mjs:85,91–100`.
2. **Hiện trạng:** chưa đăng nhập/cookie đúng; “mở câu” gọi journey, media dùng icon; không nộp đáp án; fetch không coi HTTP lỗi là operation lỗi, chưa đọc body như browser.
3. **Bằng chứng:** inject **21 request đều 401/404**, runner vẫn báo **7 operations, 0 errors, 0,00%** và có mẫu `openQuestion`. Xem `evidence/staging-runner-false-success.json`.
4. **Nguyên nhân:** đồng nhất fetch resolve với thành công; đo sai endpoint/kịch bản và thiếu invariant sau tải.
5. **Ảnh hưởng:** có thể ký nghiệm thu p95/error rate tốt trong khi không ai đăng nhập hoặc học được.
6. **Sửa:** login/cookie/CSRF thật, học liệu/media thật hợp lệ; đúng mở câu/answer/ACK/finish; đọc body và kiểm tra HTTP+nghiệp vụ; error counter/exit status; lưu raw timing và đối chiếu sổ cái.
7. **Kỳ vọng:** công cụ đo được điều nó tuyên bố; mọi request không hợp lệ hiện lỗi, không làm đẹp số.
8. **Rủi ro:** tạo tải ngoài ý muốn, làm bẩn dữ liệu; chỉ staging và tài khoản thử, mức tải có giới hạn rõ.
9. **Nghiệm thu:** 401/403/404/500/timeout/body sai phải FAIL; bài thật thành công; 30 người/30 phút và 100 nếu giữ tiêu chí; báo concurrency thực, p50/p95/p99 và invariant.

## 6. Đo truy xuất dữ liệu theo quy mô

Phép đo độc lập `admin-scale-benchmark.mjs`: SQLite **in-memory**, 23 lớp, 1.000 học sinh, 32.000 awards, 184 tuần, 32 gói/384 câu. Mỗi tab chạy ba lần, có đếm query và kích thước JSON. Không tính mạng, auth hay render.

| Tab / trường hợp | Thời gian ba lần (ms) | Số query | JSON |
| --- | --- | ---: | ---: |
| Học sinh, trang 20 dòng | 1,906 / 1,174 / 0,901 | 7 | 6530 B |
| Học liệu tuần | 0,835 / 0,612 / 0,485 | 8 | 8100 B |
| Ví, fixture không có yêu cầu đổi quà | 0,361 / 0,258 / 0,226 | 5 | 2522 B |

**Diễn giải:** phân trang/batch balance quản trị đang gọn ở dataset thử; không có bằng chứng cần thay toàn bộ data layer. Tab ví rỗng không chứng minh lịch sử đổi quà lớn cũng nhanh. Khóa/queue cloud, RLS và network không được suy ra từ SQLite. Dataset school-size chỉ dùng kiểm tra quy mô lớp/hồ sơ học sinh của Bao An, không giả lập có TKB hay dữ liệu điểm danh THCS.

### Các mục CHƯA KIỂM CHỨNG

- Truy vấn Supabase thật, EXPLAIN/ANALYZE/index usage, chi phí RLS/role runtime và cold-start Netlify cho **4.0.1**.
- Nhiều máy/giáo viên thật, 30/100 phiên hoạt động đồng thời đủ thời lượng.
- Tốc độ đọc/nghe media học liệu thật, p95 mở câu/ảnh trên hạ tầng triển khai.
- INP thực địa, thiết bị Android/iOS vật lý, mất gói và mạng 4G thực tế.
- TKB, chỗ ngồi, điểm danh/nhận xét: KHÔNG ÁP DỤNG, vì không có trong app này.

Lý do: chỉ có mã/fixture và endpoint trạng thái công khai, không có môi trường staging 4.0.1 đã triển khai để thực hiện phép đo cloud được xác nhận. Cách kiểm chứng: deploy build chốt vào staging được cấp quyền, seed dữ liệu thử, sửa runner P03, đo browser+API+DB cùng trace ID, chạy đủ kịch bản và thu raw data.

## 7. Thứ tự tối ưu đề xuất

1. Sửa công cụ và tính đúng trước: P03, chấm/thi thử/backup. Phép đo nhanh nhưng sai không có giá trị nghiệm thu.
2. Tách CSS game và tối ưu tranh trên đường tới game P01; đo cùng profile.
3. Shell kết nối nhẹ, ổn định layout và attribution CLS P02.
4. Rà ưu tiên ảnh/card và tải role/game, giữ phân trang hiện có. Không xóa cache bảo vệ hoặc kiểm tra quyền để giảm milliseconds.
5. Đo staging thật để quyết định index/pool/query/caching; không đề xuất tăng pool hoặc cache toàn bộ lớp trước khi có trace.

Có khả năng cải thiện đáng kể bằng các thay đổi có giới hạn trên nền hiện có. Hiệu quả cụ thể chỉ được công bố sau so trước/sau và kiểm tra dữ liệu; chưa có mã tối ưu nào được triển khai trong đợt này.
