# Kế hoạch sửa và tối ưu sau kiểm toán 06/11/2026

## 1. Mục tiêu và giới hạn

Giữ các tính năng Bảo An Learning đang hoạt động; sửa lỗi theo bằng chứng, giảm thời gian chờ trên điện thoại và làm thao tác thống nhất. Không viết lại sản phẩm, không thêm phân hệ TKB/điểm danh/GVCN ngoài phạm vi, không thêm danh mục kỹ năng hoặc ngân hàng câu hỏi do AI tự duyệt. Giữ bản đồ và nhân vật biểu tượng nhẹ, không cần engine đồ họa mới.

Đây là **kế hoạch đề xuất, chưa triển khai mã ứng dụng** trong đợt kiểm toán. Các việc phải được thực hiện trên dữ liệu thử/bản sao trước. Không xóa assert hoặc tăng ngưỡng để biến bài hỏng thành PASS. Không dùng số đo SQLite/PGlite cục bộ làm tốc độ Supabase thật, không dùng mô phỏng làm biên bản người dùng.

## 2. Nếu chỉ được làm 10 cải tiến

| # | Việc ưu tiên | Vì sao cần trước | Tệp chính | Điều kiện hoàn thành |
| --- | --- | --- | --- | --- |
| 1 | Phục hồi cloud nhất quán, preview và backup snapshot đúng | Hiện có thể thay SQL dù restore báo thất bại, hoặc xác nhận backup không phục hồi được | `cloud-backup-restore.mjs`, Storage adapter, CLI/panel cloud và test | Lỗi ở mọi bước không để đích dở; snapshot đủ quan hệ; preview từ chối thiếu/sai; readback hash/size thật |
| 2 | Nộp hết giờ thi thử dùng đáp án mới nhất | Hết giờ có thể xóa đáp án đã lưu và chấm 0 | `ContestMockScreen.tsx`, hai store | Có đáp án đã ACK → timeout không mất; nộp trùng idempotent; deadline do server quyết định |
| 3 | Autosave có phiên bản và trạng thái rõ | Request cũ tới sau ghi đè bài mới, UI không báo | Cùng màn và API save contest | Đảo thứ tự/timeout/two-tab không làm mất lựa chọn; UI biết đã/chưa lưu |
| 4 | Hoàn thiện xáo đáp án end-to-end và lịch sử bền | Client thiếu presentationId gây chấm nhầm; anti-repeat không bền qua instance/cold-start | `question-protocol.mjs`, hai store, contracts, client, các game/thi thử | Nội dung đúng chấm đúng mọi hoán vị; stale ID bị chặn; lượt mới đổi vị trí, retry giữ nguyên; history bền |
| 5 | Một chính sách xác thực/khóa PIN cho mọi tuyến | `oldPin` ở setup bỏ qua lockout của verify | `parent-data.mjs`, hai store, routes, UI parent | Không có đường thử PIN không giới hạn; quyền đúng phiên/trẻ, hết hạn/logout được xử lý |
| 6 | Migration SQLite có giao dịch và hồi phục | Restart giữa nâng cấp có thể giữ schema dở và bị nuốt lỗi | `online-store.mjs`, migration helpers, tests | Ngắt sau từng bước, mở lại và chạy hai lần an toàn; FK/ID/sao/tài khoản giữ nguyên |
| 7 | Nối nút ôn sai vào phiên học hợp lệ | Nút hiện có nhưng chỉ đóng phòng thi, gói review sai schema | `contest-data.mjs`, `ContestMockScreen`, `OnlineStudentWorld`, validators | Một lần bấm mở đúng câu sai; schema hợp lệ, quyền/media đúng, không farm sao |
| 8 | Giữ bản nháp preview khi quay lại tab | Giáo viên mất preview sau focus/visibility refresh | `OnlineAdminDashboard.tsx`, state import | Focus/refresh không xóa công; đổi lớp/nguồn hoặc publish mới reset theo quy tắc rõ |
| 9 | Giảm CSS/tải game và thống nhất UI điện thoại/truy cập | CSS game lớn và axe phát hiện lỗi tương phản/ARIA; cần giảm chờ và giữ khả năng đọc/chạm | `game-base.css`, entry styles/game, TownScreen, map/components | Coverage/bundle và lab trước/sau; không hồi quy màn khác; contrast/keyboard/grid đúng, viewport/zoom dùng được |
| 10 | Nghiệm thu/phát hành bằng phép đo và bằng chứng thật | Runner bỏ qua lỗi, báo cáo nhóm con và tệp chứng cứ thiếu không đủ bảo đảm phát hành | `staging_load_runner.mjs`, tests, ma trận, package/deploy docs | Runner nhận 401/404 phải FAIL; fullsuite, log tồn tại, source ID khớp website/ZIP; thử tải/người dùng đúng phạm vi |

Các dòng có thể có nhiều lỗi liên quan nhưng phục vụ một kết quả người dùng cụ thể. Quyết định ưu tiên dựa vào ảnh hưởng mất dữ liệu/chấm sai/không dùng được, không dựa vào dễ sửa.

## 3. Giai đoạn 1 — Khóa lỗi nghiêm trọng và nút thắt tính đúng

**Phạm vi:** cải tiến 1–8. Dự toán 10–16 ngày công tùy mức thay hợp đồng phiên và schema; có thể chia việc nhưng phải thống nhất hợp đồng trước. Không coi là cam kết ngày lịch.

### 3.1. Backup/restore cloud

1. Chốt manifest versioned, đủ bảng và quan hệ; export cùng một snapshot/kết nối và điểm cắt rõ.
2. Preview kiểm tra toàn bộ payload, dữ liệu quan hệ, size/hash, schema và khả năng đích; không dựa checksum envelope đơn thuần.
3. Restore có vùng staging cho media, snapshot đích, job ID và trạng thái; thiết kế commit/rollback/compensation giữa SQL và Storage.
4. Thiếu Storage khi có media phải dừng. Chỉ đếm media đã upload và đọc lại; không đếm dự kiến như đã phục hồi.
5. Thêm đường vận hành cloud có quyền quản trị, chọn đúng đích, preview/xác nhận và log; diễn tập staging, không mở endpoint phục hồi tùy ý.

**Độ khó:** cao. **Rủi ro:** dữ liệu/FK, tệp mồ côi, rollback xóa nhầm. **Cổng:** QA01–QA06; backup cuối phải thực sự khôi phục được trong lúc có giao dịch học đồng thời.

### 3.2. Thi thử: timeout, autosave và ôn sai

1. Dùng state mới nhất cho đồng hồ, ref hoặc cơ chế state machine phù hợp; tạo một lệnh nộp idempotent duy nhất.
2. Đáp án lưu có revision/cập nhật được server kiểm tra; không ghi đè bằng toàn bộ object cũ. Xác định cách chốt đáp án pending khi hết giờ, không nhận thay đổi vượt deadline.
3. UI có “đang lưu/đã lưu/chưa lưu”, retry đúng request; không nuốt lỗi bằng catch rỗng.
4. Chuẩn hóa question adapter cho `multiple-choice/options` và các dạng được hỗ trợ. Review pack tuân schema ContentPack, lấy đúng câu sai và lời giải; không dùng phương án nhiễu giả để làm đáp án quá lộ.
5. Callback ôn sai phải tạo/mở session học qua máy chủ và bảo toàn chính sách sao; không nhận pack tự chế từ client để cấp sao.

**Độ khó:** trung bình–cao. **Rủi ro:** nhiều tab, deadline, nộp hai lần, autosave còn chờ. **Cổng:** QA07–QA12.

### 3.3. Xáo đáp án

1. Chốt hợp đồng phiên trình bày, phân biệt lượt mới, sai/làm lại và retry mạng. Đưa presentationId vào type/receipt/state và mọi game/client.
2. Phiên giao thức mới bắt buộc gửi ID; máy chủ đối chiếu session/student/item/version/hoán vị. ID thiếu hoặc cũ bị từ chối có hướng dẫn đồng bộ; replay attempt đã ghi trả đúng receipt.
3. Lưu lịch sử vị trí đúng theo workspace/student/pack-version/item trong dữ liệu bền có index và cập nhật nguyên tử. Không dùng cache tiến trình hoặc quét năm play gần nhất làm nguồn quyết định cuối.
4. Lượt mới đổi vị trí đúng so với lượt mới trước; random lựa chọn còn lại; không dùng vòng A→B→C→D. Nguồn đúng bất biến, không sửa nội dung để “đổi đáp án”.
5. Sai đã ACK rồi làm lại có lượt trình bày mới nếu theo yêu cầu đã chốt; đồng hồ/gợi ý/lịch sử không được reset để tăng sao. Reload/retry cùng lượt giữ lựa chọn cũ.
6. Áp dụng cả quiz, đọc/nghe chọn đáp án, game dùng trắc nghiệm, thi thử và ôn sai. Feedback đúng chỉ số hiển thị; không gửi answer key/permutation nguồn sớm.
7. Có lộ trình tương thích phiên cũ, restart/backup/restore; không mở lại tuần đã đóng hoặc nhân đôi sao.

**Độ khó:** cao. **Rủi ro:** chấm sai, schema phiên, stale tab, lộ đáp án, clock/gợi ý. **Cổng:** QA13–QA18 và toàn bộ hồi quy scoring/media/ACK.

### 3.4. PIN, SQLite và bản nháp giáo viên

- PIN: mọi đường nhận PIN dùng verifier/lockout chung có cập nhật nguyên tử; đúng vai trò và token gắn phiên. Kiểm tra setup và verify chéo, không chỉ happy path nhập đúng.
- SQLite: có lịch sử migration, transaction/backup/FK check và fail-fast. Xử lý trạng thái bảng tạm từ lần bị ngắt, không nuốt lỗi. So cài mới với nâng cấp dữ liệu cũ.
- Preview: tách draft/preview khỏi server summary; focus refresh không reset bản nháp. Đổi class/source có kiểm tra ngữ cảnh và hết hạn; publish vẫn idempotent.

**Độ khó:** trung bình. **Rủi ro:** khóa nhầm, mất FK, giữ preview quá hạn. **Cổng:** QA19–QA24. Sau giai đoạn 1 không còn P0 hoặc lỗi chấm/mất bài đã tái hiện.

## 4. Giai đoạn 2 — Tải trang và truy xuất dữ liệu

**Phạm vi:** hiệu năng của cải tiến 9 và công cụ đo của 10. Dự toán 2–4 ngày công sau khi có baseline và bản đúng nghiệp vụ.

1. Dùng JSON lab và request waterfall của báo cáo 04 xác định tài nguyên/thao tác chậm. Không gán latency mạng vào thời gian query.
2. Tách CSS theo game/shared primitives và bỏ selector legacy chỉ khi có coverage, tìm tham chiếu và ảnh hồi quy. Tải CSS game lúc cần; prefetch có giới hạn để không tranh băng thông với ảnh câu/lượt đang mở.
3. Giữ lazy role/game hiện có. Đo JS parse/execute, long task và DOM trước khi thêm memo hoặc thư viện cache. Không memo hóa mọi component theo phỏng đoán.
4. Bảo toàn phân trang/batch balance quản trị. Đo PostgreSQL thật bằng query timing/EXPLAIN trên dữ liệu thử tương đương trước khi thêm index; có kế hoạch đảo index và theo dõi chi phí ghi.
5. Cache chỉ dữ liệu bất biến hoặc có version/TTL/invalidation rõ; authorize trước cache; không dùng cache riêng của người A cho người B; đồng hồ/nghe không bị cache phá biên nhận.
6. Viết lại kịch bản runner thành đăng nhập/cookie/CSRF thật, đúng API mở câu/media/attempt/ACK. Đọc hết body, kiểm tra HTTP và nghiệp vụ, lỗi phải tăng counter và làm exit nonzero khi vượt tiêu chí. Dùng ảnh/âm thanh thật hợp lệ.
7. Chạy ba lần cold/warm/navigation/login ở cùng profile/fixture trước/sau, không chạy đồng thời với suite nặng. Sau đó staging 30 người hoạt động đồng thời ít nhất 30 phút; nếu giữ cổng 100 thì chạy 100 thật và công bố giới hạn.

**Mục tiêu:** cải thiện bottleneck được đo, giảm byte/tài nguyên và thời gian sẵn sàng, không đổi nghiệp vụ. LCP ≤ 2,5 s, CLS ≤ 0,1 và INP field ≤ 200 ms theo điều kiện/nguồn đo phù hợp; đo lab không thay field. Câu/ảnh p95 theo tiêu chí hiện hành phải đo phía browser/network thật, không từ số handler hoặc SQLite. **Cổng:** QA25–QA28.

## 5. Giai đoạn 3 — Giao diện và thao tác thống nhất

**Phạm vi:** token/component UI, các luồng đã đúng nghiệp vụ; dự toán 2–3 ngày công và buổi thử với người dùng.

1. Chuẩn hóa màu chữ trên tranh, typography, khoảng cách, focus, nút primary/secondary và thông báo trạng thái. Bật axe contrast, sửa grid Town theo ARIA hoặc dùng semantics đơn giản đúng; vùng cuộn dùng bàn phím được.
2. Đồng bộ tên hiển thị với accessible name, tránh aria-label làm mất chữ người dùng nhìn thấy. Không thêm aria để che thiếu semantics.
3. Học sinh có nút học tiếp rõ; trạng thái đang lưu/đã lưu/lỗi nhất quán. Phụ huynh biết đang thao tác cho con nào và quyền hết hạn. Giáo viên giữ lớp, tuần và nguồn đang xử lý.
4. Đo vùng chạm thực, kiểm tra tay một bên/keyboard hiển thị, tên dài và màn nhỏ. Giữ map nhẹ, không đặt mọi hành động phụ vào vùng chính.
5. Thử 390×844, 768×1024, 1440×900 và thiết bị thật; zoom trình duyệt 200% và tăng font. Không thay zoom bằng chỉ đổi viewport.

**Độ khó:** trung bình. **Rủi ro:** CSS cascade chung, layout game, focus dialog, quét axe trước khi nội dung tải xong. **Cổng:** QA29–QA31; có ảnh trước/sau và xác nhận tác vụ người dùng.

## 6. Giai đoạn 4 — Kiểm thử và phát hành

1. Sửa bài rollback đang hardcode version 4.0.0 bằng hợp đồng phiên bản thực và kiểm tra ý nghĩa artifact; không chỉ đổi chuỗi mà bỏ kiểm tra build identity.
2. Chuyển các ca tái hiện mới thành hồi quy an toàn trong tests chuẩn, cả hai backend khi chạm server. Thêm negative/positive đúng, không dùng helper tự sửa lựa chọn sai thành đúng để thay bài âm tính.
3. Chạy typecheck, toàn bộ Node suite, build, assets và full Playwright Chrome/Edge trên build chốt. Bài bỏ qua do thiếu tệp tác giả phải có fixture thay thế hoặc nghiệm thu riêng được ghi rõ.
4. Trình kiểm tra bằng chứng: mọi PASS có tệp tồn tại, đúng build/môi trường/actual; tách SIMULATION, CHƯA KIỂM CHỨNG và người thật. Không lấy bài cũ assert fail làm chứng nhận đã sửa toàn diện.
5. Kiểm kê học liệu theo phạm vi đã chốt; nội dung và duyệt chuyên môn do chủ dự án/giáo viên cung cấp. Người học thật thử đủ luồng, không tự sinh phỏng vấn.
6. Diễn tập backup/nâng cấp/rollback staging. ZIP và website cùng version/commit/source ID; manifest phản ánh đúng pilot/release-ready. Đối chiếu hai endpoint công khai sau deploy.
7. Bàn giao nhật ký: tệp sửa, lý do, test, log, rủi ro còn lại, vận hành và người duyệt. Chỉ đóng cổng khi đủ bằng chứng cho đúng build.

**Dự toán:** 1–2 ngày công kỹ thuật, chưa gồm thời gian người dùng/học liệu và chạy tải thật. **Cổng:** QA32–QA34. Thời gian tổng phụ thuộc số người thực hiện; không dùng ngày tương lai như đã chạy.

## 7. Ma trận kiểm thử bổ sung bắt buộc

Đây là ca cần chạy **sau sửa**, hiện để `CHUA_CHAY`. Các reproduction trong evidence cố ý xác nhận lỗi hiện tại; không phải ca sản phẩm đã đạt. Giữ 60 ca cũ và bổ sung tình huống mới dưới đây, không xóa ca cũ để giảm tổng.

| ID | Ca | Kỳ vọng đóng lỗi |
| --- | --- | --- |
| QA01 | Export trong lúc play/attempt/award đang commit | Snapshot nhất quán, restore FK và invariant đạt |
| QA02 | Preview thiếu bảng/sai schema/size/hash | Từ chối trước mọi thay đổi đích |
| QA03 | Restore có media nhưng uploader null | Báo FAILED, không thay SQL |
| QA04 | Storage lỗi trước/sau commit và restart giữa restore | Đích cũ được giữ/khôi phục đúng theo thiết kế, không thành công một phần |
| QA05 | Restore vào đích có dữ liệu mới, trùng ID/tệp | Chính sách rõ, không silently bỏ xung đột hay mất dữ liệu |
| QA06 | Người vận hành cloud thực hiện từ đầu tới readback | Có đường được phân quyền, log/hash/count thật, diễn tập staging |
| QA07 | Đã trả lời/ACK rồi chờ hết giờ | Không xóa đáp án, điểm đúng |
| QA08 | Nộp tay trùng timeout/retry | Chốt đúng một kết quả idempotent |
| QA09 | Đảo thứ tự autosave | Request cũ không ghi đè đáp án mới |
| QA10 | Mạng lỗi, hai tab, save pending tại deadline | UI rõ trạng thái, server áp chính sách đúng, không mất bài im lặng |
| QA11 | Bấm ôn sai sau thi | Mở đúng session/gói hợp lệ, không chỉ đóng modal |
| QA12 | Adapter thi thử nhận pack quiz hợp lệ/learning hỗ trợ | Dùng được câu được giao đúng môn; không bỏ qua do sai schema |
| QA13 | Nguồn toàn A, mọi hoán vị có RNG điều khiển | Nội dung đúng chấm đúng mọi vị trí, feedback đúng hiển thị |
| QA14 | Client thiếu/stale/cross-session presentationId | Phiên mới bị từ chối; không chấm theo hoán vị khác |
| QA15 | Sai rồi làm lại qua UI thật | Có lượt mới theo yêu cầu, vị trí đúng đổi, clock/gợi ý/sao không reset sai |
| QA16 | Retry cùng attempt/reload | Giữ ID/thứ tự/receipt, không nhân sao |
| QA17 | Qua >5 play khác, cold-start/restart/multi-instance | Không quên vị trí mới nhất của cùng câu/phiên bản |
| QA18 | Backup/restore và game đọc/nghe/thi thử với hoán vị | Hợp đồng bền và nhất quán mọi đường; không lộ answer key |
| QA19 | Thử PIN sai xen kẽ setup/verify | Cùng bộ đếm/khóa, không đường bypass |
| QA20 | PIN đúng khi khóa/hết khóa/logout/token khác phiên | Quyền đúng hợp đồng, không rò hash/salt |
| QA21 | Ngắt migration SQLite sau từng CREATE/copy/DROP/RENAME | Restart tiếp tục/rollback an toàn, không nuốt lỗi |
| QA22 | DB cũ/cài mới, chạy migration hai lần | FK/ID/tài khoản/ví/phiên giữ đúng; tạo parent được |
| QA23 | Import preview → blur/focus/visibility/refresh | Bản nháp giữ nguyên, dữ liệu nền mới không xóa công |
| QA24 | Đổi lớp/nguồn, preview quá hạn, publish bấm nhiều lần | Reset/kiểm tra lại đúng ngữ cảnh, không publish sai/trùng |
| QA25 | Cold/warm/login/navigation 3 lần mỗi profile | Dữ liệu thô đầy đủ, điều kiện giống nhau, so trước/sau được |
| QA26 | CSS coverage và ảnh hồi quy mọi game/màn | Giảm tải game nhưng không mất trạng thái/kiểu ở màn khác |
| QA27 | Runner inject 401/404/500/timeout/body lỗi | Có error count đúng và kết quả FAIL, không 0% giả |
| QA28 | Staging 30/100 hoạt động đồng thời đúng kịch bản | Tải media/submit/ACK thật, p95 và invariant có bằng chứng |
| QA29 | Axe sau khi map/town tải hoàn chỉnh, contrast bật | Sửa critical/serious trong scope; không quét chỉ loading/skeleton |
| QA30 | Keyboard/focus/grid/scroll và tên nút | Tác vụ đầy đủ, semantics đúng, tên nhìn thấy khớp accessible name |
| QA31 | Mobile/tablet/desktop, zoom thật 200%, tăng font | Đọc/chạm/cuộn được, không mất nút/đáp án/preview |
| QA32 | Fullsuite đúng build và log của từng lệnh | Không còn test hỏng, skip có lý do; không gọi nhóm con là toàn bộ |
| QA33 | Kiểm tra mọi đường evidence + nghiệm thu người thật/học liệu | Đường tồn tại, actual đúng build; chưa kiểm chứng không bị đổi thành PASS |
| QA34 | ZIP/website/source ID, migration và rollback | Đồng nhất artifact, smoke đạt, có bản sao phục hồi được và chủ dự án duyệt |

Mỗi ca ghi engine/browser/viewport, fixture, lệnh chạy, expected/actual, thời gian thực hiện, source ID và tệp chứng cứ. P0/P1 chưa đóng thì không đánh dấu sản phẩm sẵn sàng phát hành chính thức.
